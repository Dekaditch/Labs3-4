using System;
using HoboConsolePrjct.Model.Hobo;

namespace TestProject1
{
    internal class TestHobo
    [TestClass]
    public class HoboTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}