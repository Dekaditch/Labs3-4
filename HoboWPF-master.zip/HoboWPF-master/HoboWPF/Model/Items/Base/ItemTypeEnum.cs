﻿namespace HoboConsole.Model.Items.Base
{
    public enum ItemTypeEnum
    {
        Food,
        Clothes,
        Medicine,
        Drugs,
        RealEstate,
        Garbage,
    }
}
