﻿using HoboWPF.ViewModel.DataManager;

namespace HoboWPF.ViewModel.Services.DeleteHoboService
{
    public interface IDeleteHoboService
    {
        public void DeleteHobo(IDataManager dataManager);
    }
}
