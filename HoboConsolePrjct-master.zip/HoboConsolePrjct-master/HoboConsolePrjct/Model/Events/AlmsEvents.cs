﻿using HoboConsole.Model.Stacks;
using HoboConsolePrjct.Model.Effects;
using HoboConsolePrjct.Model.Hobo;
using HoboConsolePrjct.Model.InventoryEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoboConsolePrjct.Model.Events
{
    public class AlmsEvents : IEntity
    {
        public Guid Id { get; set; }
        public EventsList EventsList { get; set; }

        public AlmsEvents(Guid id, EventsList eventsList)
        {
            Id = id;
            EventsList = eventsList;
        }

        public string ToString(int whatEvent)
        {
            List<IEvents> listOfEvents = EventsList.ShowEvent();
            return listOfEvents[whatEvent].Text;
        }

        public void ApplyEffect(IHobo hobo, int whatEvent)
        {
            List<IEvents> list = EventsList.ShowEvent();
            hobo.Money += list[whatEvent].Money;
            ChangeValueStatic.HealthChange(hobo, list[whatEvent]);
            ChangeValueStatic.EnergyChange(hobo, list[whatEvent]);
            ChangeValueStatic.EmotionalChange(hobo, list[whatEvent]);
            ChangeValueStatic.SatiationChange(hobo, list[whatEvent]);
        }
    }
}
